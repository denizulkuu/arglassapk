package com.arglasses.sender

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Foreground service that owns the full sender pipeline.
 * Fully optimized to handle automatic reconnection on screen ON/OFF cycles.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.arglasses.sender.action.START"
        const val ACTION_STOP = "com.arglasses.sender.action.STOP"
        const val ACTION_UPDATE_FPS = "com.arglasses.sender.action.UPDATE_FPS"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_TARGET_IP = "extra_target_ip"
        const val EXTRA_FPS = "extra_fps"

        private const val NOTIFICATION_CHANNEL_ID = "ar_glasses_stream"
        private const val NOTIFICATION_ID = 1

        private const val PANEL_WIDTH = 240
        private const val PANEL_HEIGHT = 320
        private const val UDP_PORT = 5005
        private const val PACKET_MAGIC: Int = 0xA55A
        private const val HEADER_BYTES = 10
        private const val MAX_PACKET_BYTES = 1400
        private const val MAX_PAYLOAD_BYTES = MAX_PACKET_BYTES - HEADER_BYTES // 1390
        private const val MAX_FRAME_BYTES = 60 * 1024
        private val JPEG_QUALITY_STEPS = intArrayOf(40, 30, 22, 16)

        // MainActivity, servisi tekrar tetiklemeden (ör. ekran döndüğünde) önce
        // yayının zaten aktif olup olmadığını buradan kontrol edebilir.
        @Volatile
        var isRunning: Boolean = false
            private set
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private var socket: DatagramSocket? = null
    private var targetAddress: InetAddress? = null

    private var frameId: Int = 0
    private var lastFrameSentAtMs: Long = 0
    private var isReceiverRegistered = false
    private var frameIntervalMs = 40L

    private val projectionManager: MediaProjectionManager by lazy {
        getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    // Ekran Kilitlenme ve Açılma Olaylarını Dinleyen Alıcı
    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    captureHandler?.post {
                        releaseVirtualDisplay()
                    }
                }
                Intent.ACTION_SCREEN_ON -> {
                    captureHandler?.post {
                        if (mediaProjection != null) {
                            setupVirtualDisplay()
                        }
                    }
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> handleStop()
            ACTION_UPDATE_FPS -> handleUpdateFps(intent)
        }
        return START_NOT_STICKY
    }

    private fun handleStart(intent: Intent) {
        startForegroundCompat()

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val resultData: Intent? =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_RESULT_DATA)
            }

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            // İzin reddedilmiş ya da veri eksik gelmiş; bozuk bir pipeline kurmadan çık
            stopSelf()
            return
        }

        // KRİTİK DÜZELTME: Servis zaten aktif bir yayın yürütürken ACTION_START tekrar
        // gelirse (ör. MainActivity ekran döndüğünde ya da arka plandan dönüldüğünde
        // yeniden oluşturulup akışı tekrar tetiklerse), eski MediaProjection, socket ve
        // HandlerThread hiç kapatılmadan üzerine yenisi kuruluyordu (kaynak sızıntısı,
        // duplike UDP trafiği). Üstelik screenStateReceiver ikinci kez register edilmeye
        // çalışılınca "Receiver already registered" hatasıyla servis çöküyordu.
        // Yeni pipeline kurmadan önce eskisini tamamen serbest bırakıyoruz.
        if (isRunning) {
            teardownPipeline(stopService = false)
        }

        // IP Adresi parametre olarak gelmezse doğrudan varsayılan IP'yi kullan
        val targetIp = intent.getStringExtra(EXTRA_TARGET_IP) ?: "172.17.232.115"

        val fps = getSharedPreferences("ar_glasses_prefs", MODE_PRIVATE)
            .getInt("fps", 25)
        frameIntervalMs = 1000L / fps.coerceAtLeast(1)

        try {
            targetAddress = InetAddress.getByName(targetIp)
            socket = DatagramSocket()
        } catch (e: Exception) {
            stopSelf()
            return
        }

        captureThread = HandlerThread("ScreenCaptureThread").also { it.start() }
        captureHandler = Handler(captureThread!!.looper)

        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handleStop()
            }
        }, captureHandler)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        // Android 13+ (API 33) context-registered receiver'lar için exported/not-exported
        // belirtilmesini zorunlu kılıyor; bu belirtilmeden registerReceiver çağrısı
        // SecurityException fırlatabiliyordu.
        ContextCompat.registerReceiver(
            this, screenStateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
        )
        isReceiverRegistered = true

        setupVirtualDisplay()
        isRunning = true
    }

    private fun handleUpdateFps(intent: Intent) {
        // Yayın sürerken FPS değiştiğinde servisi yeniden başlatmadan uygula
        val fps = intent.getIntExtra(EXTRA_FPS, 25).coerceAtLeast(1)
        frameIntervalMs = 1000L / fps
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ MediaProjection tipi bekliyor; API 34'te bu belirtilmezse
            // MissingForegroundServiceTypeException ile servis çöküyor.
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun setupVirtualDisplay() {
        releaseVirtualDisplay()

        val density = resources.displayMetrics.densityDpi

        imageReader = ImageReader.newInstance(
            PANEL_WIDTH, PANEL_HEIGHT, PixelFormat.RGBA_8888, 2
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastFrameSentAtMs < frameIntervalMs) {
                    return@setOnImageAvailableListener
                }
                lastFrameSentAtMs = now

                val bitmap = imageToBitmap(image)
                val jpegBytes = compressToJpegWithinBudget(bitmap)
                if (jpegBytes != null) {
                    sendFrame(jpegBytes)
                }
                bitmap.recycle()
            } catch (e: Exception) {
                // Ekran geçişlerindeki anlık yarış durumlarını tolere et
            } finally {
                image.close()
            }
        }, captureHandler)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ARGlassesCapture",
            PANEL_WIDTH, PANEL_HEIGHT, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            captureHandler
        )
    }

    private fun releaseVirtualDisplay() {
        try {
            virtualDisplay?.release()
        } catch (e: Exception) {}
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (e: Exception) {}
        imageReader = null
    }

    private fun imageToBitmap(image: android.media.Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * PANEL_WIDTH

        val bitmap = Bitmap.createBitmap(
            PANEL_WIDTH + rowPadding / pixelStride,
            PANEL_HEIGHT,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)

        return if (rowPadding == 0) {
            bitmap
        } else {
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, PANEL_WIDTH, PANEL_HEIGHT)
            bitmap.recycle()
            cropped
        }
    }

    private fun compressToJpegWithinBudget(bitmap: Bitmap): ByteArray? {
        for (quality in JPEG_QUALITY_STEPS) {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
            val bytes = stream.toByteArray()
            if (bytes.size <= MAX_FRAME_BYTES) {
                return bytes
            }
        }
        return null
    }

    private fun sendFrame(jpegBytes: ByteArray) {
        val sock = socket ?: return
        val addr = targetAddress ?: return

        val totalPackets = ((jpegBytes.size + MAX_PAYLOAD_BYTES - 1) / MAX_PAYLOAD_BYTES)
            .coerceAtLeast(1)

        val currentFrameId = frameId
        frameId = (frameId + 1) and 0xFFFF

        var offset = 0
        for (packetId in 0 until totalPackets) {
            val payloadLen = minOf(MAX_PAYLOAD_BYTES, jpegBytes.size - offset)

            val packet = ByteBuffer.allocate(HEADER_BYTES + payloadLen)
                .order(ByteOrder.LITTLE_ENDIAN)
            packet.putShort(PACKET_MAGIC.toShort())
            packet.putShort(currentFrameId.toShort())
            packet.putShort(packetId.toShort())
            packet.putShort(totalPackets.toShort())
            packet.putShort(payloadLen.toShort())
            packet.put(jpegBytes, offset, payloadLen)

            val datagram = DatagramPacket(
                packet.array(), packet.array().size, addr, UDP_PORT
            )
            try {
                sock.send(datagram)
            } catch (e: Exception) {}

            offset += payloadLen
        }
    }

    private fun teardownPipeline(stopService: Boolean) {
        if (isReceiverRegistered) {
            try {
                unregisterReceiver(screenStateReceiver)
            } catch (e: Exception) {}
            isReceiverRegistered = false
        }

        releaseVirtualDisplay()
        mediaProjection?.stop()
        socket?.close()
        captureThread?.quitSafely()

        mediaProjection = null
        socket = null
        captureThread = null
        captureHandler = null
        isRunning = false

        if (stopService) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun handleStop() {
        teardownPipeline(stopService = true)
    }

    override fun onDestroy() {
        handleStop()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "AR Glasses Streaming",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("AR Glasses Sender")
            .setContentText("Streaming screen to glasses...")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
    }
}