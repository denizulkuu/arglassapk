package com.arglasses.sender

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Entry point UI. Now completely automated to connect to 172.17.232.115
 * without asking the user, and triggers screen capture on launch.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        // Hedef ESP32 IP adresi buraya sabitlendi
        private const val TARGET_IP_ADDRESS = "172.17.232.115"
    }

    private lateinit var ipInput: EditText
    private lateinit var statusText: TextView
    private lateinit var startStopButton: Button
    private lateinit var fpsSeekBar: SeekBar
    private lateinit var fpsValue: TextView

    private var isStreaming = false
    private lateinit var projectionManager: MediaProjectionManager

    // Sistem ekran paylaşım izni penceresi kapandığında tetiklenir
    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                startCaptureService(result.resultCode, result.data!!)
            } else {
                Toast.makeText(this, "Screen capture permission denied.", Toast.LENGTH_LONG).show()
                setStreamingUiState(false)
            }
        }

    // Bildirim izni penceresi kapandığında (Android 13+) otomatik olarak yayını başlatır
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            beginStreamingFlow()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ipInput = findViewById(R.id.ipAddressInput)
        statusText = findViewById(R.id.statusText)
        startStopButton = findViewById(R.id.startStopButton)
        fpsSeekBar = findViewById(R.id.fpsSeekBar)
        fpsValue = findViewById(R.id.fpsValue)

        val prefs = getSharedPreferences("ar_glasses_prefs", MODE_PRIVATE)
        val savedFps = prefs.getInt("fps", 25)

        fpsSeekBar.progress = savedFps - 15
        fpsValue.text = "$savedFps FPS"

        fpsSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val fps = progress + 15
                fpsValue.text = "$fps FPS"
                prefs.edit().putInt("fps", fps).apply()

                // Servis zaten yayın yapıyorsa yeniden başlatmadan FPS'i canlı güncelle
                // (öncesinde bu değer sadece servis ilk başlarken bir kez okunuyordu).
                if (isStreaming) {
                    val updateIntent = Intent(this@MainActivity, ScreenCaptureService::class.java).apply {
                        action = ScreenCaptureService.ACTION_UPDATE_FPS
                        putExtra(ScreenCaptureService.EXTRA_FPS, fps)
                    }
                    startService(updateIntent)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // IP Giriş alanını otomatik doldur ve devre dışı bırak (XML kırılmasın diye)
        ipInput.setText(TARGET_IP_ADDRESS)
        ipInput.isEnabled = false

        projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        startStopButton.setOnClickListener {
            if (!isStreaming) {
                beginStreamingFlow()
            } else {
                stopStreaming()
            }
        }

        // KRİTİK DÜZELTME: Bu satır önceden koşulsuzdu, yani MainActivity her
        // yeniden oluşturulduğunda (ekran döndürme, arka plandan dönme vb.)
        // izin ekranını tekrar açıp servise ikinci bir ACTION_START gönderiyordu.
        // Servis zaten yayın yapıyorsa tekrar tetiklemek yerine mevcut duruma göre
        // UI'ı senkronize ediyoruz.
        if (ScreenCaptureService.isRunning) {
            setStreamingUiState(true)
        } else {
            startStreamingAutomatically()
        }
    }

    private fun startStreamingAutomatically() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                beginStreamingFlow()
            }
        } else {
            beginStreamingFlow()
        }
    }

    private fun beginStreamingFlow() {
        // IP adresini doğrudan paylaşılan tercihlere kaydet
        getSharedPreferences("ar_glasses_prefs", MODE_PRIVATE)
            .edit()
            .putString("target_ip", TARGET_IP_ADDRESS)
            .apply()

        // Doğrudan sistem ekran yakalama iznini fırlat (Kullanıcıya IP sormaz)
        projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun startCaptureService(resultCode: Int, data: Intent) {
        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            putExtra(ScreenCaptureService.EXTRA_TARGET_IP, TARGET_IP_ADDRESS)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        setStreamingUiState(true)
    }

    private fun stopStreaming() {
        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        startService(serviceIntent)
        setStreamingUiState(false)
    }

    private fun setStreamingUiState(streaming: Boolean) {
        isStreaming = streaming
        startStopButton.text = if (streaming) "Stop Streaming" else "Start Streaming"
        statusText.text = if (streaming) "Status: streaming" else "Status: idle"
    }
}
